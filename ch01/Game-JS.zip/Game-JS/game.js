/*

	遊戲JavaScript文件
	
*/
